<?php
session_start();
/**
 * Filename: Profile
 * Description: User Profile
 */
 require_once "ess/base.php";
 require_once "ess/internal.php";
 require_once "ess/theme.php";
 require_once "internal/main.php";

class Profile extends Main
{
  function __construct($array = null)
  {
    $link = parent::connect();
    $id = parent::user_ext_id($_SESSION["USERID"]);
    if($array[0] !== null){
      $id = $link->query("SELECT user_id FROM member WHERE uiu_id='".$array[0]."'");
      $id = $id->fetch_assoc();
      $id = parent::user_ext_id($id['user_id']);
    }
    $user_ext_id = (!isset($_GET["id"]) || trim($_GET["id"]) == "")?$id:$_GET["id"];
    $user_id = parent::user_int_id($user_ext_id);

    $result = $link->query("SELECT * FROM user_info WHERE user_id='".$user_id."'");
    $user_info = $result->fetch_assoc();

    $fullname = $user_info["firstname"] . " " . $user_info["middlename"] . " " . $user_info["lastname"];
    if(!is_array($user_info)) parent::head("Not Found");
    else parent::head($fullname);

    $result = $link->query("SELECT email, uiu_id FROM member WHERE user_id='".$user_id."'");
    $user = $result->fetch_assoc();
    $link = parent::close($link);
    $username = $user['uiu_id'];
    if(!is_array($user_info)){
      require_once "internal/profile/noprofile.php";
      new NoProfile();
    }else{
      $profilelink = parent::profile_link($username, $user_ext_id);
      ?>
      <div class="container internal">
        <div class="row">
          <div class="col-md-4 pull-right">
            <div>
              <a href="<?php echo $profilelink ?>" class="thumbnail">
                <?php
                echo parent::display_picture($user_info["dp"], $fullname);
                echo "<h4 class='text-center'>". $fullname ."</h4>";
                ?>
              </a>
            </div>
            <div class="panel">
              <?php
              if(parent::logged_in() && $user_id != $_SESSION["USERID"]){
                echo '<a href="'.parent::get_host(). "internal/message.php?id=" . $user_ext_id .'" class="btn btn-info">Message</a>';
                echo '<a href="#" class="btn btn-warning pull-right">Follow</a>';
              }
              ?>
            </div>

            <div id="default-block-ajax" linkAjax="internal/profile/info.php" data="<?php echo $user_ext_id ?>"><?php echo parent::loading(); ?></div>

          </div>
          <div class="col-md-8">
            <div class="page-header">
              <h3><a href="<?php echo $profilelink ?>"><?php echo $fullname ?></a></h3>
            </div>

            <div id="running-course" linkAjax="internal/profile/course.php" data="<?php echo $user_ext_id ?>"><?php echo parent::loading(); ?></div>
          </div>
          <div class="col-md-4">
            <?php
            parent::footer();
            ?>
          </div>
        </div>
      </div>
      <?php
    }
    parent::tail();
  }
}
$array = !isset($array)?null:$array;
new Profile($array);
?>
