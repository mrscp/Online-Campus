<?php
/**
 * File Name: No Profile
 */
class NoProfile
{

  function __construct()
  {
    ?>
    <div class="container internal">
      <div class="jumbotron">
        <div class="alert alert-warning">
          <h2>The Requested Address Is Invalid!</h2>
          <p>Please try again with a valid address.</p>
        </div>
      </div>
    </div>
    <?php
  }
}
?>
